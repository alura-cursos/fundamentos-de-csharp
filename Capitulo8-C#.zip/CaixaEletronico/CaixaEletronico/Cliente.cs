﻿namespace CaixaEletronico
{
    class Cliente
    {
        public string nome;
        public string rg;
        public string cpf;
        public string endereco;
    }
}